# Penguin Zoology Analytics

An interactive web application for analyzing and predicting penguin species and characteristics using machine learning models trained on the Palmer Penguins dataset.

## Features

- **Species Prediction**: Predict penguin species (Adelie, Chinstrap, Gentoo) based on morphological measurements
- **Weight Estimation**: Estimate penguin body mass using flipper length measurements
- **Interactive Interface**: User-friendly Streamlit web app with sliders and input fields
- **Data Visualization**: Jupyter notebook with comprehensive data analysis and model training

## Project Structure

- `zoology.py` - Main Streamlit application for predictions
- `penguins-project (1).ipynb` - Jupyter notebook with data analysis and model training
- `penguins_lter.csv` - Palmer Penguins dataset
- `species_model.pkl` - Trained logistic regression model for species classification
- `weigtht_model.pkl` - Trained linear regression model for weight prediction
- `label_encoder.pkl` - Label encoder for species categories

## Installation

1. Clone or download this repository
2. Install required dependencies:
   ```bash
   pip install streamlit pandas numpy scikit-learn matplotlib seaborn
   ```

## Usage

### Running the Web App

```bash
streamlit run zoology.py
```

This will launch the interactive web application where you can:
- Select island location
- Input morphological measurements (bill length, bill depth, flipper length, body mass)
- Get predictions for penguin species and estimated weight

### Data Analysis

Open `penguins-project (1).ipynb` in Jupyter to see the complete data analysis workflow including:
- Data cleaning and preprocessing
- Exploratory data analysis with visualizations
- Model training and evaluation
- Feature importance analysis

## Dataset

The project uses the Palmer Penguins dataset from the LTER (Long Term Ecological Research) program. The dataset contains measurements of three penguin species observed on three islands in the Palmer Archipelago, Antarctica.

**Features:**
- Species (Adelie, Chinstrap, Gentoo)
- Island (Torgersen, Biscoe, Dream)
- Bill length (mm)
- Bill depth (mm)
- Flipper length (mm)
- Body mass (g)
- Sex

## Models

- **Species Classification**: Logistic Regression model achieving high accuracy on penguin species prediction
- **Weight Prediction**: Linear Regression model for estimating body mass from flipper length

## Requirements

- Python 3.7+
- Streamlit
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

## License

This project is for educational purposes.