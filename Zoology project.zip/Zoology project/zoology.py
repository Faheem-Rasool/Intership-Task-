import streamlit as st
import pandas as pd
import numpy as np
import pickle 
import warnings

warnings.filterwarnings("ignore")

# Model load karne ka function
def load_models():
    try:
        with open("weigtht_model.pkl", "rb") as file:
            weight_model = pickle.load(file)
        with open("species_model.pkl", "rb") as file:
            species_model = pickle.load(file)
        with open("label_encoder.pkl", "rb") as file:
            le = pickle.load(file)
        return weight_model, species_model, le
    except FileNotFoundError:
        st.error("Model Files not found! Please check your folder.")
        return None, None, None

# Models ko variables mein assign karna
weight_model, species_model, le = load_models()

# Page configuration (Layout keyword missing tha)
st.set_page_config(page_title="Penguin Zoology App (Phenotypes)", layout="centered")
st.title("Interactive Penguin Analytics")
st.write("Enter the Biological aspects to see prediction")

# Sidebar
st.sidebar.header("Data Input Panel")
island = st.sidebar.selectbox(
    "Select the Island Location:",
    ("Torgersen", "Biscoe", "Dream")
)
flipper_length = st.sidebar.slider(
    "Flipper Length (mm):",
    170, 240, 200
)

st.subheader("Culmen Measurements")
col1, col2 = st.columns(2)

with col1:
    # Bracket aur comma ki ghalti theek kar di
    bill_length = st.number_input("Bill Length (mm)", 30.0, 60.0, 45.0)
with col2:
    bill_depth = st.number_input("Bill Depth (mm)", 10.0, 25.0, 15.0)

body_mass = st.number_input("Known Body Mass (g)", 2500, 6500, 4000)

if st.button("Run zoological Analysis"):
    if weight_model is not None:
        # Prediction Logic (Variable name theek kiya: flipper_length)
        pred_weight = weight_model.predict([[flipper_length]])[0]
        features = np.array([[bill_length, bill_depth, flipper_length, body_mass]])
        pred_id = species_model.predict(features)
        pred_name = le.inverse_transform(pred_id)[0]

        st.divider()
        st.success(f"Result for a penguin from {island} island:")
        res_col1, res_col2 = st.columns(2)
        
        # Metric display (f-string fix kiye)
        res_col1.metric("Predicted Species", f"{pred_name}")
        res_col2.metric("Estimated Weight", f"{pred_weight:.1f}g")